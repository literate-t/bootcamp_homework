#include "ui.h"

int main() {
	EventLoop();
}